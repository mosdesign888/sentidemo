const $=i=>document.getElementById(i),hd=$('hd'),nav=$('nav');
const days=['一','二','三','四','五','六','日'];
const rows=[['早上','10:00–13:00',[1,1,1,0,1,1,0]],['下午','14:00–17:30',[1,1,1,1,1,1,0]],['晚上','18:00–21:00',[1,1,1,1,1,0,0]]]; // 門診時間：1=看診，請改這裡
const ti=(new Date().getDay()+6)%7;
let h='<tr><th></th>'+days.map((d,i)=>`<th class="${i==ti?'today':''}">${d}</th>`).join('')+'</tr>';
rows.forEach(r=>{h+=`<tr><td>${r[0]} ${r[1]}</td>`+r[2].map((v,i)=>`<td class="${i==ti?'today':''}"><span class="${v?'d':'x'}"></span></td>`).join('')+'</tr>'});
['sch','sch2','sch3'].forEach(i=>$(i)&&($(i).innerHTML=h));
if($('today'))$('today').textContent='今日（週'+days[ti]+'）'+(rows.filter(r=>r[2][ti]).map(r=>r[0]+' '+r[1]).join('、')||'休診');
const dopen=o=>document.body.classList.toggle('dopen',o);
document.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>dopen(true));
$('dx').onclick=$('mask').onclick=()=>dopen(false);
addEventListener('keydown',e=>{if(e.key==='Escape')dopen(false)});
const sub=document.body.classList.contains('sub'),sc=()=>hd.classList.toggle('solid',sub||scrollY>60);sc();addEventListener('scroll',sc);
$('bg').onclick=()=>nav.classList.toggle('open');
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('show');io.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll('.fade').forEach(el=>io.observe(el));
// Mega menu：延遲收合，避免滑鼠移動時消失
let mt;const hm=[...document.querySelectorAll('.hasm')];
hm.forEach(li=>{li.onmouseenter=()=>{clearTimeout(mt);hm.forEach(x=>x.classList.toggle('open',x==li));hd.classList.add('mopen')};li.onmouseleave=()=>{mt=setTimeout(()=>{li.classList.remove('open');hd.classList.remove('mopen')},200)}});
// 旋轉木馬
document.querySelectorAll('.car').forEach(c=>{const t=c.querySelector('.ct'),st=()=>t.clientWidth*.8;c.querySelector('.prev').onclick=()=>t.scrollBy({left:-st(),behavior:'smooth'});c.querySelector('.next').onclick=()=>t.scrollBy({left:st(),behavior:'smooth'})});
// 服務項目分類切換
const q=new URLSearchParams(location.search).get('c')||'';
document.querySelectorAll('section').forEach(s=>{const its=[...s.querySelectorAll('[data-c]')],tb=[...s.querySelectorAll('.tabs [data-t]')];if(!tb.length)return;
const show=c=>{its.forEach(e=>e.style.display=(!c||e.dataset.c==c)?'':'none');tb.forEach(b=>b.classList.toggle('on',b.dataset.t==c))};
show(q);tb.forEach(b=>b.onclick=()=>show(b.dataset.t))});
// 案例分享：篩選 + 顯示更多
const sg=$('sg');
if(sg){const cards=[...sg.querySelectorAll('.sc')],st={c:q,d:''},STEP=4;let n=STEP;const fb=[...document.querySelectorAll('.flt button')];
fb.forEach(b=>{if(b.dataset.v)b.querySelector('i').textContent=cards.filter(c=>c.dataset[b.dataset.k]==b.dataset.v).length});
const run=()=>{const m=cards.filter(c=>(!st.c||c.dataset.c==st.c)&&(!st.d||c.dataset.d==st.d));cards.forEach(c=>c.style.display='none');m.slice(0,n).forEach(c=>c.style.display='');
$('cnt').textContent=m.length;$('more').style.display=m.length>n?'':'none';fb.forEach(b=>b.classList.toggle('on',(st[b.dataset.k]||'')==(b.dataset.v||'')))};
fb.forEach(b=>b.onclick=()=>{st[b.dataset.k]=b.dataset.v||'';n=STEP;run()});$('more').onclick=()=>{n+=STEP;run()};run()}
