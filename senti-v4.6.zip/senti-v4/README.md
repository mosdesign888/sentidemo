# 聖緹美學診所 網站封包 v4（預覽版）
解壓縮後用瀏覽器開啟 index.html。
## 要先替換的資料
- LINE 連結：全站搜尋 `https://line.me/R/ti/p/@senti`，換成診所 LINE 官方帳號網址
- 104 連結：全站搜尋 `https://www.104.com.tw/`
- 門診時間表：js/main.js 的 `rows`
- 地址、電話、醫師、開業執照字號：各頁與頁尾
## 字體
中文 PingFang TC（蘋方）細體、英文 Avenir，皆為 Apple 系統字體。Windows / Android 會自動改用 Noto Sans TC 與 Nunito Sans（已由 Google Fonts 載入）。
## 換圖
`<div class="ph" data-label="XXX"></div>` → `<div class="ph" style="background:url(img/xxx.jpg) center/cover"></div>`
## 部署（Cloudflare Pages）
Workers & Pages → Create → Pages → Upload assets → 拖入整個資料夾。
## 上線前
刪除每頁 `noindex`；醫療廣告用語與案例分享請由醫師或法務確認。
